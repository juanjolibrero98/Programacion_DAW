package U2_Practica_Entregable;

import java.util.Scanner;

public class Clase_Ej2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Por favor, introduzca un número entero positivo:");
        long intento= sc.nextLong();

    }
}
